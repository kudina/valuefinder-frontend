const Inactive = ()=>{
    return(
        <div>All Inactive contracts
            
        </div>
    )
}

export default Inactive