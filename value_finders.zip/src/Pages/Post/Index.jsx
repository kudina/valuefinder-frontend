import Header from "../../component/Header"
import CreatePost from '../../component/Post/CreatePost'
const Post =()=>{
    return(
        <div>
            <Header/>
            <CreatePost/>
        </div>
    )
}

export default Post