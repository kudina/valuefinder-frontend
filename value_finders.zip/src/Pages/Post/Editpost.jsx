import Header from "../../component/Header"
//import CreatePost from '../../component/Post/CreatePost'
import Edit from '../../component/Post/Edit'
const Editpost =()=>{
    return(
        <div>
            <Header/>
            <Edit/>
        </div>
    )
}

export default Editpost